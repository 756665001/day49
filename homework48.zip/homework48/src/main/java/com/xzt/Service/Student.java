package com.xzt.Service;

public interface Student {
     void readBook();
     void playGame();
}
